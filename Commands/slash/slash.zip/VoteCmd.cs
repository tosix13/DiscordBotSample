using Discord;
using Discord.WebSocket;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBot.NetCore.Commands.slash
{
    public class VoteCmd : ISlashCommand
    {
        public string _cmdName { get; set; } = "vote";
        public Callback.SlashCommandRegion _region { get; set; } = Callback.SlashCommandRegion.global;

        public SlashCommandBuilder CommandBuild()
        {
            var retCmd = new SlashCommandBuilder();
            retCmd.WithName(_cmdName);
            retCmd.WithDescription("create vote list");
            retCmd.AddOption("title", ApplicationCommandOptionType.String, "vote title", isRequired: true);
            retCmd.AddOption("items", ApplicationCommandOptionType.String, "vote items splited space", isRequired: true);

            return retCmd;
        }

        public async Task CommandAction(SocketSlashCommand iCommand)
        {
            var title = iCommand.Data.Options.ElementAt(0).Value as string;
            var items = (iCommand.Data.Options.ElementAt(1).Value as string).Split(" ");

            var embed = new EmbedBuilder();
            embed.WithTitle(title);
            embed.WithAuthor(iCommand.User.Username, iCommand.User.GetAvatarUrl() ?? iCommand.User.GetDefaultAvatarUrl());

            Emoji icon = null;
            var descriptions = new StringBuilder();
            IEmote[] emotes = new IEmote[items.Length];
            for (int ith = 0; ith < items.Length; ith++)
            {
                icon = new Emoji(Common.ALPHABET_ICONS[ith]);
                descriptions.AppendLine($"{icon}\t{items[ith]}");
                emotes[ith] = icon;
            }

            embed.WithDescription(descriptions.ToString());

            await iCommand.RespondAsync("create vote list.");
            await iCommand.Channel.SendMessageAsync(embed: embed.Build()).GetAwaiter().GetResult().AddReactionsAsync(emotes);
        }
    }
}
