using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBot.NetCore.Commands.slash
{
    public class DiceCmd : ISlashCommand
    {
        public string _cmdName { get; set; } = "dice";
        public Callback.SlashCommandRegion _region { get; set; } = Callback.SlashCommandRegion.global;

        public SlashCommandBuilder CommandBuild()
        {
            var retCmd = new SlashCommandBuilder();
            retCmd.WithName(_cmdName);
            retCmd.WithDescription("roll the dice and calc result");
            retCmd.AddOption("face", ApplicationCommandOptionType.Integer, "dice faces", isRequired: true);
            retCmd.AddOption("throw", ApplicationCommandOptionType.Integer, "dice throw count", isRequired: true);

            return retCmd;
        }

        public async Task CommandAction(SocketSlashCommand iCommand)
        {
            int? tmpValue;

            tmpValue = iCommand.Data.Options.ElementAt(0).Value as int?;
            if (null == tmpValue || tmpValue <= 0)
            {
                throw new Exception("Invalid argument");
            }
            var face = tmpValue.Value;

            tmpValue = iCommand.Data.Options.ElementAt(1).Value as int?;
            if (null == tmpValue || tmpValue <= 0)
            {
                throw new Exception("Invalid argument");
            }
            var throwCnt = tmpValue.Value;

            var result = 0;
            List<int> results = new List<int>();
            for (int ith = 0; ith < throwCnt; ith++)
            {
                result = new Random().Next(1, face + 1);
                results.Add(result);
            }
            int sum = results.Sum();
            string average = ((double)sum / throwCnt).ToString("#,0.00");

            // embed枠生成
            var embed = new EmbedBuilder();
            embed.WithTitle("出目");
            embed.WithDescription(string.Join(", ", results));

            await iCommand.RespondAsync($"{face}面ダイスを{throwCnt}回振ったよ!\n  合計: {sum}、平均値: {average}", embed: embed.Build());
        }
    }
}
