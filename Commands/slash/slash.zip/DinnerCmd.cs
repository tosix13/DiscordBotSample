using Discord;
using Discord.WebSocket;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Json;

namespace DiscordBot.NetCore.Commands.slash
{
    public class Recipe
    {
        public string foodImageUrl { get; set; }
        public string mediumImageUrl { get; set; }
        public string nickname { get; set; }
        public int pickup { get; set; }
        public string rank { get; set; }
        public string recipeCost { get; set; }
        public string recipeDescription { get; set; }
        public int recipeId { get; set; }
        public string recipeIndication { get; set; }
        public List<string> recipeMaterial { get; set; }
        public string recipePublishday { get; set; }
        public string recipeTitle { get; set; }
        public string recipeUrl { get; set; }
        public int shop { get; set; }
        public string smallImageUrl { get; set; }
    }

    public class Response
    {
        public List<Recipe> result { get; set; }
    }

    public class DinnerCmd : ISlashCommand
    {
        private string RAKUTEN_API_PATH = $"https://app.rakuten.co.jp/services/api/Recipe/CategoryRanking/20170426?format=json&applicationId={EntryPoint._config.rakuten_applicationID}";
        public string _cmdName { get; set; } = "dinner";
        public Callback.SlashCommandRegion _region { get; set; } = Callback.SlashCommandRegion.global;

        public SlashCommandBuilder CommandBuild()
        {
            var retCmd = new SlashCommandBuilder();
            retCmd.WithName(_cmdName);
            retCmd.WithDescription("return top recipe ranking");

            return retCmd;
        }

        public async Task CommandAction(SocketSlashCommand iCommand)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetFromJsonAsync<Response>(RAKUTEN_API_PATH);
            foreach (var recipe in response.result)
            {
                await iCommand.RespondAsync(embed: SendEmbed(recipe).Build());
            }
        }

        private EmbedBuilder SendEmbed(Recipe iRacipe)
        {
            var embed = new EmbedBuilder();
            embed.AddField("レシピ名", $"{iRacipe.recipeTitle}", true);
            embed.AddField("URL", $"{iRacipe.recipeUrl}", true);
            embed.AddField("予算", $"{iRacipe.recipeCost}", true);
            embed.WithThumbnailUrl(iRacipe.smallImageUrl);
            return embed;
        }
    }
}
