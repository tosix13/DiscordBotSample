using Discord;
using Discord.WebSocket;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBot.NetCore.Commands.slash
{
    public class UserInfoCmd : ISlashCommand
    {
        private const string FULL_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
        private const string RECENT_DATETIME_FORMAT = "HH:mm:ss";
        public string _cmdName { get; set; } = "userinfo";
        public Callback.SlashCommandRegion _region { get; set; } = Callback.SlashCommandRegion.global;

        public SlashCommandBuilder CommandBuild()
        {
            var retCmd = new SlashCommandBuilder();
            retCmd.WithName(_cmdName);
            retCmd.WithDescription("return pong");
            retCmd.WithDescription("show user info");
            retCmd.AddOption("userid", ApplicationCommandOptionType.User, "user id", isRequired: true);

            return retCmd;
        }

        public async Task CommandAction(SocketSlashCommand iCommand)
        {
            var user = iCommand.Data.Options.ElementAt(0).Value as SocketGuildUser;

            string replyTxt = null;
            var embed = new EmbedBuilder();

            if (user.IsBot)
            {
                replyTxt = "Bots are not human.";
            }
            else
            {
                embed.WithAuthor(x =>
                {
                    x.Name = user.Username;
                    x.IconUrl = user.GetAvatarUrl();
                });
                embed.AddField("User", $"{user.Username}#{user.Discriminator}", true);
                embed.AddField("Display Name", user.DisplayName, true);
                embed.AddField("Member ID", user.Id, true);
                embed.AddField("Status", user.Status, true);
                embed.AddField("Joined Guild", user.JoinedAt.Value.ToString(FULL_DATETIME_FORMAT), true);
                // embed.AddField("Account Created", user.CreatedAt.ToString(FULL_DATETIME_FORMAT), true);
                embed.AddField("Roles", user.Roles.Count - 1, true);
                embed.WithTimestamp(DateTimeOffset.Now);
                embed.WithFooter(x =>
                {
                    x.Text = $"Requested By {iCommand.User.Username}";
                    x.IconUrl = iCommand.User.GetAvatarUrl();
                });

                if (null == user.Activities)
                {
                    embed.AddField("Activity", "None", true);
                }
                else
                {
                    if (user.Activities is SpotifyGame spot)
                    {
                        embed.AddField("Listening To", "Spotify", true);
                        embed.AddField("Track", spot.TrackTitle, true);
                        embed.AddField("Artist(s)", string.Join(", ", spot.Artists), true);
                        embed.AddField("Album", spot.AlbumTitle, true);
                    }
                    else if (user.Activities is CustomStatusGame statusGame)
                    {
                        embed.AddField("Activity", statusGame.Name, true);
                        embed.AddField("Details", statusGame.Details, true);
                        embed.AddField("Playing Since", statusGame.CreatedAt, true);
                        embed.WithColor(Color.Magenta);
                    }
                    else if (user.Activities is RichGame richGame)
                    {
                        embed.AddField("Activity", richGame.Name, true);
                        embed.AddField("Details", richGame.Details, true);
                        embed.AddField("Playing Since", richGame.Timestamps.Start.Value.ToString(RECENT_DATETIME_FORMAT), true);
                        embed.AddField("Time Playing", (DateTimeOffset.Now - richGame.Timestamps.Start).Value.ToString(RECENT_DATETIME_FORMAT), true);
                    }
                    else
                    {
                        // object activity = "None";
                        // if (null != user.Activities.First().Name)
                        // {
                        //     activity = user.Activities.First().Name;
                        // }
                        // embed.AddField("Activity", activity, true);
                    }
                }
            }

            await iCommand.RespondAsync(replyTxt, embed: embed.Build());
        }
    }
}
