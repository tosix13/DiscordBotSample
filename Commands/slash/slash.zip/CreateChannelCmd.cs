using Discord;
using Discord.WebSocket;
using System.Threading.Tasks;

namespace DiscordBot.NetCore.Commands.slash
{
    public class CreateChannelCmd : ISlashCommand
    {
        public string _cmdName { get; set; } = "ping";
        public Callback.SlashCommandRegion _region { get; set; } = Callback.SlashCommandRegion.global;

        public SlashCommandBuilder CommandBuild()
        {
            var retCmd = new SlashCommandBuilder();
            retCmd.WithName(_cmdName);
            retCmd.WithDescription("return pong");

            return retCmd;
        }

        public async Task CommandAction(SocketSlashCommand iCommand)
        {
            await iCommand.RespondAsync("pong");
        }
    }
}
